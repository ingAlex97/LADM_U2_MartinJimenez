package com.example.ladm_u2_p3_martinjimenez

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var vDado1 = 0
    var vDado2 = 0
    var jugador1 = Hilo(this,1)
    var jugador2 = Hilo(this,2)
    var jugador3 = Hilo(this,3)
    var jugador4 = Hilo(this,4)
    var ronda = 0
    var pj1 = 0
    var pj2 = 0
    var pj3 = 0
    var pj4 = 0



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        this.setTitle("Juego de dados")


        button.setOnClickListener {
            if(!jugador1.isAlive){
                jugador1.start()
                ronda=1
                noRonda.setText(ronda.toString())
            }
            else{
                reiniciar()
            }



        }//boton


    }//onCreate

    fun reiniciar(){
        puntosj1.setText("0")
        puntosj2.setText("0")
        puntosj3.setText("0")
        puntosj4.setText("0")

        ronda=0
        turnosEtiquetas(1)
        cambiarTurno(4)

    }
    fun tirarDados(){
        vDado1 = (1..6).random()
        vDado2 = (1..6).random()



        when(vDado1){
            1->{dado1.setImageResource(R.drawable.uno)}
            2->{dado1.setImageResource(R.drawable.dos)}
            3->{dado1.setImageResource(R.drawable.tres)}
            4->{dado1.setImageResource(R.drawable.cuatro)}
            5->{dado1.setImageResource(R.drawable.cinco)}
            6->{dado1.setImageResource(R.drawable.seis)}
        }//dado1
        when(vDado2){
            1->{dado2.setImageResource(R.drawable.uno)}
            2->{dado2.setImageResource(R.drawable.dos)}
            3->{dado2.setImageResource(R.drawable.tres)}
            4->{dado2.setImageResource(R.drawable.cuatro)}
            5->{dado2.setImageResource(R.drawable.cinco)}
            6->{dado2.setImageResource(R.drawable.seis)}
        }//dado2
    }//tirar dados

    fun turnosEtiquetas(jugador:Int){
        when(jugador){
            1->{
                turnoj1.setText("tu turno")
                turnoj2.setText("espera")
                turnoj3.setText("espera")
                turnoj4.setText("espera")

                turnoj1.setTextColor(Color.parseColor("#00FF00")) //Color verde segun yo
                turnoj2.setTextColor(Color.parseColor("#0000FF")) //Color azul segun yo
                turnoj3.setTextColor(Color.parseColor("#0000FF")) //Color azul segun yo
                turnoj4.setTextColor(Color.parseColor("#0000FF")) //Color azul segun yo
            }
            2->{
                turnoj1.setText("espera")
                turnoj2.setText("tu turno")
                turnoj3.setText("espera")
                turnoj4.setText("espera")

                turnoj1.setTextColor(Color.parseColor("#0000FF"))
                turnoj2.setTextColor(Color.parseColor("#00FF00")) //Color verde segun yo
                turnoj3.setTextColor(Color.parseColor("#0000FF")) //Color azul segun yo
                turnoj4.setTextColor(Color.parseColor("#0000FF")) //Color azul segun yo
            }
            3->{
                turnoj1.setText("espera")
                turnoj2.setText("espera")
                turnoj3.setText("tu turno")
                turnoj4.setText("espera")

                turnoj1.setTextColor(Color.parseColor("#0000FF"))
                turnoj2.setTextColor(Color.parseColor("#0000FF")) //Color azul segun yo
                turnoj3.setTextColor(Color.parseColor("#00FF00")) //Color verde segun yo
                turnoj4.setTextColor(Color.parseColor("#0000FF")) //Color azul segun yo
            }
            4->{
                turnoj1.setText("espera")
                turnoj2.setText("espera")
                turnoj3.setText("espera")
                turnoj4.setText("tu turno")

                turnoj1.setTextColor(Color.parseColor("#0000FF"))
                turnoj2.setTextColor(Color.parseColor("#0000FF")) //Color azul segun yo
                turnoj3.setTextColor(Color.parseColor("#0000FF")) //Color verde segun yo
                turnoj4.setTextColor(Color.parseColor("#00FF00")) //Color azul segun yo
            }
        }
    }

    fun asignarPuntos(jugador:Int){
        when(jugador){
            1->{
                 pj1 = vDado1+vDado2+puntosj1.text.toString().toInt()
                puntosj1.setText(pj1.toString())
            }
            2->{
                 pj2 = vDado1+vDado2+puntosj2.text.toString().toInt()
                puntosj2.setText(pj2.toString())
            }
            3->{
                 pj3 = vDado1+vDado2+puntosj3.text.toString().toInt()
                puntosj3.setText(pj3.toString())
            }
            4->{
                 pj4 = vDado1+vDado2+puntosj4.text.toString().toInt()
                puntosj4.setText(pj4.toString())
            }
        }

    }

    fun cambiarTurno(jugador:Int){
        when(jugador){
            1->{
                jugador1.pausar()

                if(!jugador2.isAlive){
                    jugador2.start()
                }
                else{ jugador2.despausar()}
            }
            2->{
                jugador2.pausar()

                if(!jugador3.isAlive){
                    jugador3.start()
                }
                else{ jugador3.despausar()}
            }
            3->{
                jugador3.pausar()

                if(!jugador4.isAlive){
                    jugador4.start()
                }
                else{ jugador4.despausar()}
            }
            4->{


                ronda++
                if(ronda==5){
                    declararGanador()
                    jugador4.pausar()

                }
                else{
                    jugador4.pausar()
                    jugador1.despausar()
                    noRonda.setText(ronda.toString())
                }


            }



        }//when
    }

    fun declararGanador(){

        if(pj1>pj2 && pj1>pj3 && pj1>pj4){
            jugador4.mensaje("WINNER J1","!Felicidades Jugador #1¡ HAS GANADO CON '" + pj1.toString() + "' PUNTOS")}//gana J1
        else{
            if(pj2>pj1 && pj2>pj3 && pj2>pj4){
              jugador4.mensaje("WINNER J2","!Felicidades Jugador #2¡ HAS GANADO CON '" + pj2.toString() + "' PUNTOS")}//gana J2
            else{
                if(pj3>pj1 && pj3>pj2 && pj3>pj4){
                    jugador4.mensaje("WINNER J3","!Felicidades Jugador #3¡ HAS GANADO CON '" + pj3.toString() + "' PUNTOS")}//gana J3
                else{
                    if(pj4>pj1 && pj4>pj2 && pj4>pj3){
                        jugador4.mensaje("WINNER J4","!Felicidades Jugador #4¡ HAS GANADO CON '" + pj4.toString() + "' PUNTOS")}//ganaJ4
                    else{
                        jugador4.mensaje("no hay ganador :'(", "Hubo un empate y me dio flojera hacer el algoritmo para detectar quienes empataron, ahi se lo debo profe")}
                }
            }
        }//


    }



}//MainActivity


class Hilo(p:MainActivity, j:Int) : Thread(){
    var puntero= p
    var iniciado=true
    var jugador=j
    var pausa =false
    var i=0
    var titulo = ""
    var mens=""
var mensaje =false

    override fun run() {
        super.run()
        mensaje = false
        iniciado = true
        while (iniciado){

            if (!pausa) {
                puntero.runOnUiThread {
                    puntero.turnosEtiquetas(jugador)
                }//runOnUiThread
                    sleep(200)
                while (i < 30) {
                    sleep(30)

                    puntero.runOnUiThread {
                        puntero.tirarDados()
                        i++
                    }//runOnUiThread
                }//while
                    i=0

                puntero.runOnUiThread {
                    puntero.tirarDados()
                    sleep(200)
                    puntero.asignarPuntos(jugador)
                }

                sleep(1000)
                puntero.cambiarTurno(jugador)

                if(mensaje){
                    puntero.runOnUiThread {
                        AlertDialog.Builder(puntero)
                            .setTitle(titulo)
                            .setMessage(mens)
                            .setPositiveButton("Oki"){d,i->}.show()
                    }
                    mensaje=false
                }
            }//pausa

    }//whileIniciado

        sleep(2000)
    }


    fun pausar (){
        pausa=true
    }

    fun despausar(){
        pausa = false
    }

    fun detener(){
        iniciado=false
    }

    fun mensaje(t:String,m:String){
        titulo=t
        mens=m
        mensaje=true

    }

}


