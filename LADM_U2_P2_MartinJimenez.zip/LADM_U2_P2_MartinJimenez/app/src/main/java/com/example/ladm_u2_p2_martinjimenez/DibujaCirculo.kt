package com.example.ladm_u2_p2_martinjimenez

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent

class DibujaCirculo(){
    var x=0f
    var y=0f
    var r=0f
    var incX = 5f
    var incY = 5f

    constructor(cx: Int,cy: Int,radio:Int): this(){
        x=cx.toFloat()
        y=cy.toFloat()
        r=radio.toFloat()

        if(radio<=10){
            incX = 10f
            incY = 10f}

            incX = (3/r)*100
            incY = (3/r)*100



    }



    fun pintar(canvas: Canvas, paint: Paint, c:Int){
        paint.color=c
        canvas.drawCircle(x,y,r,paint)

        paint.color = Color.WHITE
        canvas.drawCircle(x+(r/10)*4,y-(r/10)*6,r/10,paint)
    }//pintar


    fun rebote(ancho:Int, alto:Int){
        x+= incX
        if(x<=r || x>=ancho-r){
            incX *= -1
        }
        y+= incY
        if(y<=r || y>=alto-r){
            incY *= -1
        }

    }


}