package com.example.ladm_u2_p2_martinjimenez

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    var lienzo:Lienzo? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lienzo = Lienzo(this)
        setContentView(lienzo!!)
        Hilo (this).start()

        this.setTitle("Practica 2 por Martín Jimenez")

    }
}
