package com.example.ladm_u2_p2_martinjimenez

class Hilo (p:MainActivity):Thread(){
    var puntero = p

    override fun run() {
        super.run()

        while(true){
            sleep(20)
            puntero.runOnUiThread {
                puntero.lienzo!!.animarFigura()
            }
        }
    }
}