package com.example.ladm_u2_p2_martinjimenez

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.MediaPlayer
import android.view.MotionEvent
import android.view.View

class Lienzo (p:MainActivity) : View(p){
    var c1 = DibujaCirculo(100,200,20)
    var c2 = DibujaCirculo(200,300,40)
    var c3 = DibujaCirculo(400,500,80)
    var c4 = DibujaCirculo(150,700,100)
    var c5 = DibujaCirculo(300,400,150)
    var c6 = DibujaCirculo(500,600,10)




    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        var paint = Paint()



        canvas.drawColor(Color.BLACK)



        c1.pintar(canvas, paint, Color.RED)
        c2.pintar(canvas, paint, Color.BLUE)
        c3.pintar(canvas, paint, Color.GREEN)
        c4.pintar(canvas, paint, Color.YELLOW)
        c5.pintar(canvas, paint, Color.GRAY)
        c6.pintar(canvas, paint, Color.CYAN)




    }//onDraw



    fun animarFigura() {
        c1.rebote(width, height)
        c2.rebote(width, height)
        c3.rebote(width, height)
        c4.rebote(width, height)
        c5.rebote(width, height)
        c6.rebote(width, height)
        invalidate()
    }

}//class lienzo

