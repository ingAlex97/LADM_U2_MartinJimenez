package com.example.ladm_u2_practica1_martinjimenez

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import java.util.*
import kotlin.collections.ArrayList

class Lienzo (p: MainActivity): View(p){


      var copo=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo2=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo3=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo4=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo5=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo6=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo7=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo8=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo9=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo10=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo11=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo12=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo13=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo14=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo15=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo16=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo17=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo18=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo19=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo20=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo21=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo22=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo23=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo24=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo25=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo26=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo27=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo28=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo29=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo30=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo31=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo32=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo33=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo34=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo35=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo36=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo37=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo38=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo39=Figuras((0..700).random(), (-500..0).random(), 5)
      var copo40=Figuras((0..700).random(), (-500..0).random(), 5)

    override fun onDraw(c: Canvas) {


        super.onDraw(c)

        var p = Paint()

//---------------------  Dibujos estaticos --------------------------------------
        //Fondo
        p.color= Color.rgb(183,188,204)
        c.drawPaint(p)

        // pasto
        p.color = Color.rgb(45,156,1)
        c.drawRect(0f,800f,750f,1259f,p)

        // arbol
        p.color = Color.rgb(133,62,0)
        c.drawRect(100f,700f,140f,850f,p)

        p.color = Color.rgb(45,120,1)
        c.drawCircle(120f,670f,70f,p)
        c.drawCircle(120f,600f,70f,p)

        //casa
        p.color = Color.rgb(209,7,31)
        c.drawRect(290f, 600f,650f,850f,p)

        //puerta
        p.color = Color.rgb(133,62,0)
        c.drawRect(480f,700f,560f,850f,p)
        //ventana
        p.color = Color.rgb(199,211,211)
        c.drawCircle(380f,730f,50f,p)
        p.color = Color.BLACK
        c.drawLine(330f,730f,430f,730f,p)
        c.drawLine(380f,680f,380f,780f,p)

        c.drawLine(270f,600f,670f,600f,p)
        c.drawLine(270f,600f,470f,450f,p)
        c.drawLine(470f,450f,670f,600f,p)

        //nube
        p.color = Color.rgb(199,211,211)
        c.drawCircle(140f,200f,40f,p)
        c.drawCircle(160f,200f,40f,p)
        c.drawCircle(180f,200f,40f,p)
        c.drawCircle(200f,200f,40f,p)
        c.drawCircle(220f,200f,40f,p)
        c.drawCircle(240f,200f,40f,p)
        c.drawCircle(260f,200f,40f,p)
        c.drawCircle(280f,200f,40f,p)


        c.drawCircle(180f,170f,40f,p)
        c.drawCircle(200f,170f,40f,p)
        c.drawCircle(220f,170f,40f,p)
        c.drawCircle(240f,170f,40f,p)

        c.drawCircle(210f,140f,40f,p)

        //sol
        p.color = Color.rgb(251,231,3)
        c.drawCircle(730f,20f,70f,p)
//-----------------------------------------------------------------------------

        //nieve


        copo.pintar(c,p,Color.WHITE)
        copo2.pintar(c,p)
        copo3.pintar(c,p)
        copo4.pintar(c,p)
        copo5.pintar(c,p)
        copo6.pintar(c,p)
        copo7.pintar(c,p)
        copo8.pintar(c,p)
        copo9.pintar(c,p)
        copo10.pintar(c,p)
        copo11.pintar(c,p)
        copo12.pintar(c,p)
        copo13.pintar(c,p)
        copo14.pintar(c,p)
        copo15.pintar(c,p)
        copo16.pintar(c,p)
        copo17.pintar(c,p)
        copo18.pintar(c,p)
        copo19.pintar(c,p)
        copo20.pintar(c,p)
        copo21.pintar(c,p)
        copo22.pintar(c,p)
        copo23.pintar(c,p)
        copo24.pintar(c,p)
        copo25.pintar(c,p)
        copo26.pintar(c,p)
        copo27.pintar(c,p)
        copo28.pintar(c,p)
        copo29.pintar(c,p)
        copo30.pintar(c,p)
        copo31.pintar(c,p)
        copo32.pintar(c,p)
        copo33.pintar(c,p)
        copo34.pintar(c,p)
        copo35.pintar(c,p)
        copo36.pintar(c,p)
        copo37.pintar(c,p)
        copo38.pintar(c,p)
        copo39.pintar(c,p)
        copo40.pintar(c,p)

    }

    fun animarCopos() {

             copo.cambiarCoordenadas(height,width)
             copo2.cambiarCoordenadas(height,width)
             copo3.cambiarCoordenadas(height,width)
             copo4.cambiarCoordenadas(height,width)
             copo5.cambiarCoordenadas(height,width)
             copo6.cambiarCoordenadas(height,width)
             copo7.cambiarCoordenadas(height,width)
             copo8.cambiarCoordenadas(height,width)
             copo9.cambiarCoordenadas(height,width)
             copo10.cambiarCoordenadas(height,width)
             copo11.cambiarCoordenadas(height,width)
             copo12.cambiarCoordenadas(height,width)
             copo13.cambiarCoordenadas(height,width)
             copo14.cambiarCoordenadas(height,width)
             copo15.cambiarCoordenadas(height,width)
             copo16.cambiarCoordenadas(height,width)
             copo17.cambiarCoordenadas(height,width)
             copo18.cambiarCoordenadas(height,width)
             copo19.cambiarCoordenadas(height,width)
             copo20.cambiarCoordenadas(height,width)
             copo21.cambiarCoordenadas(height,width)
             copo22.cambiarCoordenadas(height,width)
             copo23.cambiarCoordenadas(height,width)
             copo24.cambiarCoordenadas(height,width)
             copo25.cambiarCoordenadas(height,width)
             copo26.cambiarCoordenadas(height,width)
             copo27.cambiarCoordenadas(height,width)
             copo28.cambiarCoordenadas(height,width)
             copo29.cambiarCoordenadas(height,width)
             copo30.cambiarCoordenadas(height,width)
             copo31.cambiarCoordenadas(height,width)
             copo32.cambiarCoordenadas(height,width)
             copo33.cambiarCoordenadas(height,width)
             copo34.cambiarCoordenadas(height,width)
             copo35.cambiarCoordenadas(height,width)
             copo36.cambiarCoordenadas(height,width)
             copo37.cambiarCoordenadas(height,width)
             copo38.cambiarCoordenadas(height,width)
             copo39.cambiarCoordenadas(height,width)
             copo40.cambiarCoordenadas(height,width)
            invalidate()

    }
}//class