package com.example.ladm_u2_practica1_martinjimenez

import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import java.lang.Thread.sleep

class Figuras(){
    //coordenadas x y
    //tipo de figura 1 = circulo, 2=rectangulo
    //Codigo para determinar ESTA_EN_AREA (retorna true si esta y un false si no está)
    //metodo para arrastrar la figura geometrica
    //otro para pintar
    var x=0f
    var y=0f
    var r=0f
    var incY = 2
    var rany=false
    var fin=0


    constructor(cx: Int,cy: Int,radio:Int): this(){
        x=cx.toFloat()
        y=cy.toFloat()
        r=radio.toFloat()
    }


    fun pintar(canvas: Canvas, paint: Paint, c:Int){
        paint.color=c
        canvas.drawCircle(x,y,r,paint)
    }//pintar

    fun pintar(canvas: Canvas, paint: Paint){
        canvas.drawCircle(x,y,r,paint)
    }//pintar



    fun cambiarCoordenadas( alto:Int,ancho:Int){
        y+= incY
        if(!rany){ fin = (alto-440..alto-10).random()
            rany=true
        }
        if( y>=fin){
            y = (-500..0).random().toFloat()
            rany=false
            x = (0..700).random().toFloat()
        }

    }

}